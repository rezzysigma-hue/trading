package com.eventedge.ai

import org.junit.Assert.assertEquals
import org.junit.Test

class SmokeTest {
    @Test
    fun moneyFormattingIsStable() {
        assertEquals("10.00", String.format(java.util.Locale.UK, "%.2f", 10.0))
    }
}
