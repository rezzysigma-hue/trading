package com.eventedge.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF172033)
private val Blue = Color(0xFF2563EB)
private val Page = Color(0xFFF5F7FB)
private val Muted = Color(0xFF687386)
private val Green = Color(0xFF16845B)
private val Orange = Color(0xFFB86A12)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Blue,
                    background = Page,
                    surface = Color.White,
                    onSurface = Ink,
                    onBackground = Ink
                )
            ) {
                EventEdgeApp()
            }
        }
    }
}

private enum class Screen(val label: String) {
    HOME("Home"), EVENTS("Events"), MARKETS("Markets"), LAB("Strategy Lab"),
    PORTFOLIO("Portfolio"), SETTINGS("Settings")
}

private data class MarketEvent(
    val title: String,
    val category: String,
    val source: String,
    val time: String,
    val summary: String,
    val sample: Boolean = true
)

private data class Holding(val ticker: String, val units: Double, val average: Double)

@Composable
private fun EventEdgeApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("eventedge", 0) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var mode by remember { mutableStateOf(prefs.getString("mode", "Paper trading") ?: "Paper trading") }
    var balance by remember { mutableDoubleStateOf(prefs.getFloat("balance", 10f).toDouble()) }
    var pnl by remember { mutableDoubleStateOf(prefs.getFloat("pnl", 0f).toDouble()) }
    var stopped by remember { mutableStateOf(prefs.getBoolean("stopped", false)) }
    var refreshState by remember { mutableStateOf("Sample data loaded") }
    var lastRefresh by remember { mutableStateOf("Not connected") }
    var events by remember {
        mutableStateOf(
            listOf(
                MarketEvent("Drought risk in major growing regions", "Crop failure", "Demo dataset", "Sample", "Illustrative event. Check official crop reports and rainfall observations before drawing conclusions."),
                MarketEvent("Shipping route disruption reported", "Shipping", "Demo dataset", "Sample", "Illustrative event. Freight rates, insurance costs and alternative routes may change company economics."),
                MarketEvent("Defence procurement announcement", "War & defence", "Demo dataset", "Sample", "Illustrative event. A contract announcement does not guarantee a share-price increase."),
                MarketEvent("Energy supply outlook changes", "Oil & gas", "Demo dataset", "Sample", "Illustrative event. Compare supply, inventories, substitutes and what current prices already imply."),
                MarketEvent("New trade restriction proposed", "Sanctions & tariffs", "Demo dataset", "Sample", "Illustrative event. Distinguish proposals from enacted measures and assess affected supply chains.")
            )
        )
    }
    var selectedFilter by remember { mutableStateOf("All") }
    var ticker by remember { mutableStateOf("AAPL.US") }
    var marketText by remember { mutableStateOf("No market data fetched yet. Stooq daily history may be delayed and is not a real-time execution quote.") }
    var marketBusy by remember { mutableStateOf(false) }
    var orderTicker by remember { mutableStateOf("AAPL") }
    var orderAmount by remember { mutableStateOf("1.00") }
    var portfolioMessage by remember { mutableStateOf("Paper account starts with £10.00. No real orders can be placed.") }
    var backtestResult by remember { mutableStateOf("Run a sample backtest to see a reproducible illustrative result.") }
    var backtestRuns by remember { mutableIntStateOf(0) }
    var eventQuery by remember { mutableStateOf("") }

    fun persist() {
        prefs.edit()
            .putString("mode", mode)
            .putFloat("balance", balance.toFloat())
            .putFloat("pnl", pnl.toFloat())
            .putBoolean("stopped", stopped)
            .apply()
    }

    Scaffold(
        containerColor = Page,
        topBar = {
            TopAppBarCompat(
                title = "EventEdge AI",
                subtitle = mode,
                stopped = stopped,
                onStop = {
                    stopped = !stopped
                    persist()
                }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf(Screen.HOME, Screen.EVENTS, Screen.MARKETS, Screen.LAB, Screen.PORTFOLIO, Screen.SETTINGS).forEach { item ->
                    NavigationBarItem(
                        selected = screen == item,
                        onClick = { screen = item },
                        icon = {
                            Icon(
                                imageVector = when (item) {
                                    Screen.HOME -> Icons.Default.Home
                                    Screen.EVENTS -> Icons.Default.Public
                                    Screen.MARKETS -> Icons.Default.ShowChart
                                    Screen.LAB -> Icons.Default.Science
                                    Screen.PORTFOLIO -> Icons.Default.AccountBalanceWallet
                                    Screen.SETTINGS -> Icons.Default.Settings
                                },
                                contentDescription = item.label
                            )
                        },
                        label = { Text(item.label, fontSize = 10.sp, maxLines = 1) },
                        alwaysShowLabel = true
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (screen) {
                Screen.HOME -> HomeScreen(balance, pnl, mode, stopped, refreshState, lastRefresh, events) { screen = it }
                Screen.EVENTS -> EventsScreen(events, selectedFilter, { selectedFilter = it }, eventQuery, { eventQuery = it }, refreshState, {
                    refreshState = "Fetching public news…"
                    refreshState = "Fetch started"
                }, {
                    // Real HTTP request runs off the main thread; GDELT is public and no API key is required.
                }, onLoadNews = {
                    refreshState = "Fetching GDELT news…"
                }, onNewsResult = { newEvents, status ->
                    if (newEvents.isNotEmpty()) events = newEvents + events.filter { it.sample }
                    refreshState = status
                    lastRefresh = SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date())
                })
                Screen.MARKETS -> MarketsScreen(ticker, { ticker = it }, marketText, marketBusy, {
                    marketBusy = true
                    marketText = "Fetching daily historical data…"
                }, {
                    marketBusy = false
                }, { result ->
                    marketText = result
                    marketBusy = false
                    lastRefresh = SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date())
                })
                Screen.LAB -> LabScreen(backtestRuns, backtestResult, {
                    backtestRuns += 1
                    val gross = listOf(0.34, -0.12, 0.21, 0.08, -0.05, 0.16, -0.07, 0.19).take(5 + (backtestRuns % 4))
                    val net = gross.sum() - gross.size * 0.025
                    backtestResult = "Illustrative simulation · ${gross.size} sample outcomes · estimated net result ${if (net >= 0) "+" else ""}£${"%.2f".format(Locale.UK, net)}. Not historical market evidence."
                })
                Screen.PORTFOLIO -> PortfolioScreen(balance, pnl, stopped, orderTicker, { orderTicker = it }, orderAmount, { orderAmount = it }, portfolioMessage, {
                    val amount = orderAmount.toDoubleOrNull()
                    if (stopped) {
                        portfolioMessage = "Order blocked: emergency stop is active."
                    } else if (amount == null || amount <= 0.0) {
                        portfolioMessage = "Enter a valid positive amount."
                    } else if (amount > balance) {
                        portfolioMessage = "Insufficient simulated cash."
                    } else {
                        balance -= amount
                        // Simulated buy only: no actual price feed or broker execution.
                        portfolioMessage = "Simulated order recorded for $orderTicker: £${"%.2f".format(Locale.UK, amount)}. Units and execution price are illustrative only."
                        persist()
                    }
                }, {
                    stopped = true
                    persist()
                    portfolioMessage = "Emergency stop enabled. Simulated orders are blocked."
                })
                Screen.SETTINGS -> SettingsScreen(mode, { mode = it; persist() }, stopped, {
                    stopped = true
                    persist()
                }, refreshState, lastRefresh, {
                    events = demoEvents()
                    refreshState = "Demo data restored"
                    lastRefresh = "Not connected"
                })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarCompat(title: String, subtitle: String, stopped: Boolean, onStop: () -> Unit) {
    TopAppBar(
        title = {
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Ink)
                Text(subtitle, fontSize = 11.sp, color = Muted)
            }
        },
        actions = {
            Surface(
                shape = RoundedCornerShape(30.dp),
                color = if (stopped) Color(0xFFFFE8E8) else Color(0xFFE4F6EC),
                modifier = Modifier.padding(end = 8.dp).clickable { onStop() }
            ) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (stopped) Icons.Default.StopCircle else Icons.Default.Shield, null,
                        tint = if (stopped) Color(0xFFB42318) else Green, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(if (stopped) "Stopped" else "Safe", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Page)
    )
}

@Composable
private fun HomeScreen(
    balance: Double, pnl: Double, mode: String, stopped: Boolean, refreshState: String,
    lastRefresh: String, events: List<MarketEvent>, navigate: (Screen) -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Good to see you", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("Event intelligence and simulated trading in one place.", color = Muted, fontSize = 14.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Paper balance", "£${money(balance)}", "Starting demo balance £10", Modifier.weight(1f))
                MetricCard("Net P/L", "${if (pnl > 0) "+" else ""}£${money(pnl)}", "Simulated only", Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Sensors, null, tint = Blue)
                        Spacer(Modifier.width(8.dp))
                        Text("System status", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    }
                    StatusRow("App mode", mode, Icons.Default.Smartphone)
                    StatusRow("Event data", refreshState, Icons.Default.Public)
                    StatusRow("Last refresh", lastRefresh, Icons.Default.Schedule)
                    StatusRow("Real-money orders", if (stopped) "Disabled · stop active" else "Disabled · prototype", Icons.Default.Lock)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Recent event signals", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                TextButton(onClick = { navigate(Screen.EVENTS) }) { Text("View all") }
            }
        }
        items(events.take(3)) { EventCard(it) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEBF2FF)), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Info, null, tint = Blue)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Research mode", fontWeight = FontWeight.SemiBold)
                        Text("This build uses demo events and simulated orders. It does not promise profits or submit orders to a broker.", fontSize = 13.sp, color = Ink)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, footnote: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text(footnote, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun StatusRow(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Muted, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun EventsScreen(
    events: List<MarketEvent>, filter: String, onFilter: (String) -> Unit,
    query: String, onQuery: (String) -> Unit, status: String,
    onRefresh: () -> Unit, unused: () -> Unit, onLoadNews: () -> Unit,
    onNewsResult: (List<MarketEvent>, String) -> Unit
) {
    val filters = listOf("All", "War & defence", "Crop failure", "Oil & gas", "Shipping", "Natural disasters", "Disease", "Critical minerals", "Macro", "Sanctions", "Corporate")
    var loading by remember { mutableStateOf(false) }
    var localStatus by remember { mutableStateOf(status) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Event intelligence", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Track public developments and the industries they may affect.", color = Muted)
        }
        item {
            OutlinedTextField(
                value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search events or categories") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true, shape = RoundedCornerShape(14.dp)
            )
        }
        item {
            Button(
                onClick = {
                    loading = true
                    localStatus = "Fetching GDELT public news…"
                    onLoadNews()
                    // Use GDELT's public DOC API. The result is parsed defensively.
                    GlobalScope.launch(Dispatchers.IO) {
                        val result = fetchGdelt()
                        withContext(Dispatchers.Main) {
                            onNewsResult(result.first, result.second)
                            localStatus = result.second
                            loading = false
                        }
                    }
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                else Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text(if (loading) "Refreshing public news…" else "Refresh public news")
            }
        }
        item { Text(localStatus, color = Muted, fontSize = 12.sp) }
        item {
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filters) { f ->
                    FilterChip(selected = filter == f, onClick = { onFilter(f) }, label = { Text(f) })
                }
            }
        }
        val visible = events.filter {
            (filter == "All" || it.category.equals(filter, ignoreCase = true) ||
                (filter == "Macro" && it.category.contains("economic", true))) &&
                (query.isBlank() || it.title.contains(query, true) || it.summary.contains(query, true) || it.category.contains(query, true))
        }
        if (visible.isEmpty()) item { EmptyState("No matching events", "Try another category or search term.") }
        items(visible) { EventCard(it) }
        item {
            Text("Public news is not automatically a verified trading signal. Confirm material claims and assess whether the market has already reacted.", fontSize = 12.sp, color = Muted)
        }
    }
}

private suspend fun fetchGdelt(): Pair<List<MarketEvent>, String> = withContext(Dispatchers.IO) {
    var connection: HttpURLConnection? = null
    try {
        val query = java.net.URLEncoder.encode("(war OR drought OR crop failure OR shipping OR sanctions OR oil supply)", "UTF-8")
        val url = URL("https://api.gdeltproject.org/api/v2/doc/doc?query=$query&mode=ArtList&format=json&maxrecords=20&sort=DateDesc")
        connection = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 10000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "EventEdgeAI/0.1 (public event research prototype)")
        }
        if (connection.responseCode !in 200..299) return@withContext Pair(emptyList(), "News request failed: HTTP ${connection.responseCode}")
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        val root = JSONObject(body)
        val articles = root.optJSONArray("articles")
        val list = mutableListOf<MarketEvent>()
        if (articles != null) {
            for (i in 0 until articles.length()) {
                val a = articles.optJSONObject(i) ?: continue
                val title = a.optString("title", "").trim()
                if (title.isBlank()) continue
                val domain = a.optString("domain", "GDELT")
                val date = a.optString("seendate", "Recent")
                val url = a.optString("url", "")
                val text = "$title $url".lowercase(Locale.ROOT)
                val category = when {
                    listOf("war", "missile", "defence", "military", "conflict").any { it in text } -> "War & defence"
                    listOf("drought", "crop", "harvest", "wheat", "corn", "flood").any { it in text } -> "Crop failure"
                    listOf("shipping", "port", "canal", "freight", "vessel").any { it in text } -> "Shipping"
                    listOf("sanction", "tariff", "trade restriction").any { it in text } -> "Sanctions"
                    listOf("oil", "gas", "energy", "pipeline").any { it in text } -> "Oil & gas"
                    listOf("disease", "outbreak", "pandemic").any { it in text } -> "Disease"
                    listOf("copper", "lithium", "uranium", "mineral").any { it in text } -> "Critical minerals"
                    listOf("earthquake", "hurricane", "wildfire", "disaster").any { it in text } -> "Natural disasters"
                    else -> "Corporate"
                }
                list.add(MarketEvent(title, category, domain, date, "Public news result. Open the source article to verify details before interpreting market impact. ${if (url.isNotBlank()) url else ""}", false))
            }
        }
        Pair(list, if (list.isEmpty()) "No articles returned. Try again later; sample events remain available." else "Loaded ${list.size} public articles via GDELT. Headlines are unverified signals.")
    } catch (e: Exception) {
        Pair(emptyList(), "News unavailable: ${e.javaClass.simpleName}. Check connection; sample events remain available.")
    } finally {
        connection?.disconnect()
    }
}

@Composable
private fun EventCard(event: MarketEvent) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Surface(color = categoryColor(event.category).copy(alpha = 0.12f), shape = RoundedCornerShape(8.dp)) {
                    Text(event.category, color = categoryColor(event.category), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                }
                Spacer(Modifier.weight(1f))
                Text(if (event.sample) "SAMPLE" else "PUBLIC FEED", color = Muted, fontSize = 9.sp)
            }
            Text(event.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(event.summary, color = Muted, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Source, null, tint = Muted, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(5.dp))
                Text(event.source, color = Muted, fontSize = 10.sp)
                Spacer(Modifier.weight(1f))
                Text(event.time, color = Muted, fontSize = 10.sp)
            }
        }
    }
}

private fun categoryColor(category: String) = when (category) {
    "War & defence" -> Color(0xFF9A3412)
    "Crop failure" -> Color(0xFF16845B)
    "Shipping" -> Color(0xFF2563EB)
    "Oil & gas" -> Color(0xFF7C3AED)
    "Sanctions" -> Color(0xFFB42318)
    else -> Blue
}

@Composable
private fun MarketsScreen(
    ticker: String, onTicker: (String) -> Unit, result: String, busy: Boolean,
    onFetch: () -> Unit, onFinish: () -> Unit, onResult: (String) -> Unit
) {
    var status by remember { mutableStateOf("Historical daily data only; not an executable live quote.") }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Market explorer", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Inspect symbols and public historical price data.", color = Muted)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(value = ticker, onValueChange = onTicker, label = { Text("Stooq symbol") }, placeholder = { Text("AAPL.US") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(
                        onClick = {
                            val symbol = ticker.trim().lowercase(Locale.ROOT)
                            if (!symbol.matches(Regex("[a-z0-9.\\-]{1,20}"))) {
                                onResult("Invalid symbol. Use a provider-compatible symbol such as aapl.us.")
                            } else {
                                onFetch()
                                GlobalScope.launch(Dispatchers.IO) {
                                    val text = fetchStooq(symbol)
                                    withContext(Dispatchers.Main) { onResult(text); onFinish() }
                                }
                            }
                        },
                        enabled = !busy, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        else Icon(Icons.Default.Download, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (busy) "Loading…" else "Fetch daily history")
                    }
                    Text(status, color = Muted, fontSize = 12.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Provider response", fontWeight = FontWeight.SemiBold)
                    Text(result, fontSize = 13.sp, color = Ink)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4E5)), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Warning, null, tint = Orange)
                    Spacer(Modifier.width(8.dp))
                    Text("Stooq data may be delayed or unavailable. This screen is for research, not live order pricing.", fontSize = 12.sp)
                }
            }
        }
    }
}

private suspend fun fetchStooq(symbol: String): String = withContext(Dispatchers.IO) {
    var connection: HttpURLConnection? = null
    try {
        connection = (URL("https://stooq.com/q/d/l/?s=$symbol&i=d").openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 10000
            setRequestProperty("User-Agent", "EventEdgeAI/0.1")
        }
        if (connection.responseCode !in 200..299) return@withContext "Market data request failed: HTTP ${connection.responseCode}"
        val rows = connection.inputStream.bufferedReader().use { it.readLines() }
        if (rows.size <= 1 || rows.firstOrNull()?.contains("Date,Open,High,Low,Close,Volume") != true) {
            return@withContext "No daily history returned for $symbol. Check the symbol or provider availability."
        }
        val data = rows.drop(1).takeLast(8)
        "Symbol: ${symbol.uppercase(Locale.ROOT)}\nProvider: Stooq daily CSV\nRows returned: ${rows.size - 1}\n\n" +
            data.joinToString("\n") + "\n\nData is historical and may be delayed. It is not a live bid/ask quote."
    } catch (e: Exception) {
        "Market data unavailable: ${e.javaClass.simpleName}. Check the connection and try again."
    } finally {
        connection?.disconnect()
    }
}

@Composable
private fun LabScreen(runs: Int, result: String, onRun: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Strategy laboratory", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Test hypotheses before risking capital.", color = Muted)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Experiment queue", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    listOf("Event-driven supply shock", "News momentum", "Commodity-linked equities", "Relative-value pairs").forEachIndexed { i, label ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = Color(0xFFE8EEFA), shape = CircleShape) {
                                Text("${i + 1}", modifier = Modifier.padding(8.dp), color = Blue, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(label, fontWeight = FontWeight.Medium)
                                Text("Candidate · requires historical validation", color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    Button(onClick = onRun, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Run sample simulation")
                    }
                }
            }
        }
        item {
            MetricCard("Experiments run this session", runs.toString(), "Sample simulations only", Modifier.fillMaxWidth())
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Latest result", fontWeight = FontWeight.SemiBold)
                    Text(result, fontSize = 13.sp)
                }
            }
        }
        item { Text("This initial laboratory demonstrates the UI and workflow; it is not yet a full historical backtester or a trained predictive model.", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
private fun PortfolioScreen(
    balance: Double, pnl: Double, stopped: Boolean,
    ticker: String, onTicker: (String) -> Unit, amount: String, onAmount: (String) -> Unit,
    message: String, onBuy: () -> Unit, onStop: () -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Portfolio", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Local paper account · no broker connected", color = Muted)
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Cash", "£${money(balance)}", "Simulated", Modifier.weight(1f))
            MetricCard("Net P/L", "£${money(pnl)}", "No real holdings", Modifier.weight(1f))
        } }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Create simulated order", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    OutlinedTextField(value = ticker, onValueChange = onTicker, label = { Text("Symbol") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = amount, onValueChange = onAmount, label = { Text("Amount (£)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = onBuy, enabled = !stopped, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.ShoppingCart, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Record simulated buy")
                    }
                    OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.StopCircle, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Emergency stop")
                    }
                    Text(message, color = Muted, fontSize = 12.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4E5)), shape = RoundedCornerShape(16.dp)) {
                Text("No real order is sent. This prototype reserves the entered amount from simulated cash; it does not yet calculate units, fills or real portfolio valuation.", modifier = Modifier.padding(14.dp), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    mode: String, onMode: (String) -> Unit, stopped: Boolean, onStop: () -> Unit,
    status: String, lastRefresh: String, onReset: () -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Settings", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Manage app mode and local data.", color = Muted)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Operating mode", fontWeight = FontWeight.SemiBold)
                    listOf("Offline demo", "Paper trading").forEach { option ->
                        Row(Modifier.fillMaxWidth().clickable { onMode(option) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = mode == option, onClick = { onMode(option) })
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(option, fontWeight = FontWeight.Medium)
                                Text(if (option == "Offline demo") "Sample events and local simulation" else "Local simulated orders; no broker connected", color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    Divider()
                    Text("Data status", fontWeight = FontWeight.SemiBold)
                    Text(status, color = Muted, fontSize = 12.sp)
                    Text("Last successful refresh: $lastRefresh", color = Muted, fontSize = 12.sp)
                    Button(onClick = onReset, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.Restore, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Restore sample data")
                    }
                    OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.StopCircle, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (stopped) "Emergency stop remains active" else "Activate emergency stop")
                    }
                }
            }
        }
        item {
            Text("Privacy & security", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Text("This prototype stores settings and simulated cash locally. It does not collect payment details, store broker credentials or place real trades.", color = Muted, fontSize = 12.sp)
        }
        item {
            Text("Version 0.1.0 · EventEdge AI · Built for Android 8.0 and newer", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun EmptyState(title: String, detail: String) {
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.SearchOff, null, tint = Muted, modifier = Modifier.size(32.dp))
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(detail, color = Muted, fontSize = 12.sp)
    }
}

private fun money(value: Double): String = String.format(Locale.UK, "%.2f", value)

private fun demoEvents() = listOf(
    MarketEvent("Drought risk in major growing regions", "Crop failure", "Demo dataset", "Sample", "Illustrative event. Check official crop reports and rainfall observations before drawing conclusions."),
    MarketEvent("Shipping route disruption reported", "Shipping", "Demo dataset", "Sample", "Illustrative event. Freight rates, insurance costs and delivery times may change company economics."),
    MarketEvent("Defence procurement announcement", "War & defence", "Demo dataset", "Sample", "Illustrative event. A contract announcement does not guarantee a share-price increase."),
    MarketEvent("Energy supply outlook changes", "Oil & gas", "Demo dataset", "Sample", "Illustrative event. Compare supply, inventories, substitutes and current market expectations."),
    MarketEvent("New trade restriction proposed", "Sanctions", "Demo dataset", "Sample", "Illustrative event. Distinguish proposals from enacted measures.")
)
